-- Sample items
INSERT INTO items (Title, start_date, end_date, start_price, result_id) VALUES
('Smartphone X1', '2025-07-05', '2025-07-11', 15500.00, 1),
('Canon EOS R7', '2025-07-14', '2025-07-19', 89500.00, 2),
('KitchenAid Mixer', '2025-07-21', '2025-07-28', 26000.00, 3),
('MacBook Pro 14', '2025-07-08', '2025-07-13', 168000.00, 4),
('Nike Air Zoom', '2025-07-09', '2025-07-12', 7999.00, 5),
('Samsung QLED TV', '2025-07-22', '2025-07-27', 76000.00, 6),
('Fitbit Versa 3', '2025-07-08', '2025-07-13', 11300.00, 7);

-- Sample Auction_result
INSERT INTO Auction_result (result_id, auction_time, Details) VALUES
(1, '2025-07-01 10:00:00', 'Item sold to highest bidder'),
(2, '2025-07-02 11:15:00', 'Auction closed without bids'),
(3, '2025-07-03 14:20:00', 'Reserve price not met'),
(4, '2025-07-04 09:45:00', 'Buyer withdrew before payment'),
(5, '2025-07-05 13:10:00', 'Item sold at reserve price'),
(6, '2025-07-06 16:30:00', 'Seller cancelled listing'),
(7, '2025-07-07 17:50:00', 'Highest bidder declined offer');

-- Sample customers
INSERT INTO customers (Username, Name, Password, Gender, Phone_no, Title) VALUES
('user00', 'Arjun Sinha', 'sun11moon', 'M', '9819011111', 'Smartphone X1'),
('user01', 'Neha Dey', 'alpha549', 'F', '9829022222', 'Canon EOS R7'),
('user02', 'Rajiv Menon', 'rkpass@22', 'M', '9838033333', 'KitchenAid Mixer'),
('user03', 'Sneha Verma', 'v3rma!4U', 'F', '9848044444', 'MacBook Pro 14'),
('user04', 'Mihir Bhat', 'LOG!nhamm', 'M', '9857055555', 'Nike Air Zoom'),
('user05', 'Tanvi Das', 'D45tan#1', 'F', '9866066666', 'Samsung QLED TV'),
('user06', 'Amar Jain', 'luckynine', 'M', '9877077777', 'Fitbit Versa 3');