-- Create items table
CREATE TABLE items (
    Title VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_price DECIMAL(10,2) NOT NULL,
    result_id NUMERIC(10),
    PRIMARY KEY (Title),
    FOREIGN KEY (Result_Id) REFERENCES Auction_result(Result_Id)
);

--Create Auction_result table
CREATE TABLE Auction_result (
    Result_ID NUMERIC(10) PRIMARY KEY,
    auction_time DATETIME NOT NULL,
    Details VARCHAR(255)
);

--Create Bids table
CREATE TABLE customers (
    Username VARCHAR(50) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Password VARCHAR(50) UNIQUE,
    Gender CHAR(1) CHECK (Gender IN (‘M’,’F’,’O’)),
    Phone_no VARCHAR(15) ,
    Title VARCHAR(100),
    FOREIGN KEY (Title) REFERENCES
items(Title)
);