import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class InitialPage extends JFrame {

    private JLabel activeAuctionsLabel;
    private JLabel totalItemsLabel;
    private JLabel highestBidLabel;
    private JLabel totalBidsLabel;

    public InitialPage() {
        setTitle("Auction Management System");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // Header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(new EmptyBorder(16, 12, 16, 12));

        // Hamburger Menu Icon
        JLabel menuIcon = new JLabel("≡"); // Unicode for three lines
        menuIcon.setFont(new Font("Segoe UI", Font.BOLD, 34));
        menuIcon.setCursor(new Cursor(Cursor.HAND_CURSOR));
        menuIcon.setForeground(new Color(50, 70, 105));
        headerPanel.add(menuIcon, BorderLayout.WEST);

        // Title
        JLabel titleLabel = new JLabel("AUCTION SYSTEM", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(new Color(33, 37, 41));
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        // Hamburger menu with panels
        JPopupMenu menu = new JPopupMenu();
        addMenuAction(menu, "Auction Results", () -> new AuctionResultPanel().setVisible(true));
        addMenuAction(menu, "Customers", () -> new CustomerPanel().setVisible(true));
        addMenuAction(menu, "Items", () -> new ItemsPanel().setVisible(true));
        addMenuAction(menu, "Payments", () -> new PaymentsPanel().setVisible(true));
        addMenuAction(menu, "Bids", () -> new BidPanel().setVisible(true));
        addMenuAction(menu, "Watchlist", () -> new WatchlistPanel().setVisible(true));
        addMenuAction(menu, "Customer Phones", () -> new CustomerPhonePanel().setVisible(true));

        menuIcon.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                menu.show(menuIcon, 0, menuIcon.getHeight());
            }
        });

        // Logout button in bottom-left
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setPreferredSize(new Dimension(900, 50));
        footerPanel.setBackground(new Color(240, 240, 245));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        logoutBtn.setBackground(new Color(255,0,0));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(8, 30, 8, 30));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new AuctionPlatformLanding().setVisible(true);
                dispose();
            }
        });
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutBtn);
        footerPanel.add(logoutPanel, BorderLayout.WEST);

        // Summary stats boxes (rest of footer)
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 20, 12));
        statsPanel.setBorder(new EmptyBorder(0, 110, 0, 30));
        statsPanel.setOpaque(false);
        activeAuctionsLabel = createStatLabel("Active Auctions: 0");
        totalItemsLabel = createStatLabel("Total Items: 0");
        highestBidLabel = createStatLabel("Highest Bid: $0.00");
        totalBidsLabel = createStatLabel("Total Bids: 0");
        statsPanel.add(activeAuctionsLabel);
        statsPanel.add(totalItemsLabel);
        statsPanel.add(highestBidLabel);
        statsPanel.add(totalBidsLabel);
        footerPanel.add(statsPanel, BorderLayout.CENTER);

        add(footerPanel, BorderLayout.SOUTH);

        // (Optionally, place a graphic or welcome message in center)
        JLabel welcome = new JLabel("<html><div style='text-align:center;'>"
                + "<h1 style='color:#2977FF;'>Welcome to Auction Dashboard!</h1>"
                + "<p style='font-size:18px; color:#5A6482;'>Select a menu option from the left</p>"
                , SwingConstants.CENTER);
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        welcome.setForeground(new Color(90, 100, 130));
        add(welcome, BorderLayout.CENTER);

        // Load stats
        loadSummaryData();
    }

    private void addMenuAction(JPopupMenu menu, String label, Runnable action) {
        JMenuItem item = new JMenuItem(label);
        item.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        item.setForeground(new Color(39, 174, 96));
        item.addActionListener(e -> action.run());
        menu.add(item);
    }

    private JLabel createStatLabel(String text) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180), 1));
        lbl.setOpaque(true);
        lbl.setBackground(new Color(220, 230, 250));
        return lbl;
    }

    private void loadSummaryData() {
        try (Connection con = DBUtil.getConnection()) {
            Statement stmt = con.createStatement();

            // Active auctions (items with future enddate)
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM items WHERE end_date > start_date");
            if (rs.next()) activeAuctionsLabel.setText("Active Auctions: " + rs.getInt(1));

            // Total items
            rs = stmt.executeQuery("SELECT COUNT(*) FROM items");
            if (rs.next()) totalItemsLabel.setText("Total Items: " + rs.getInt(1));

            // Highest bid
            rs = stmt.executeQuery("SELECT MAX(bid_amount) FROM bid");
            if (rs.next()) highestBidLabel.setText(String.format("Highest Bid: $%.2f", rs.getDouble(1)));

            // Total bids
            rs = stmt.executeQuery("SELECT COUNT(*) FROM bid");
            if (rs.next()) totalBidsLabel.setText("Total Bids: " + rs.getInt(1));

        } catch (Exception ex) {
            // Set error messages in the labels if needed
            activeAuctionsLabel.setText("Active Auctions: ?");
            totalItemsLabel.setText("Total Items: ?");
            highestBidLabel.setText("Highest Bid: ?");
            totalBidsLabel.setText("Total Bids: ?");
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignore) {}

        SwingUtilities.invokeLater(() -> new InitialPage().setVisible(true));
    }
}