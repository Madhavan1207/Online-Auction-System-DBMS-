import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AuctionResultFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField idField, detailsField;
    private JButton insertButton, refreshButton;

    public AuctionResultFrame() {
        setTitle("Auction Results");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"Result_id", "Auction_time", "Details"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());
        idField = new JTextField(5);
        detailsField = new JTextField(15);
        insertButton = new JButton("Insert");
        refreshButton = new JButton("Refresh");

        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Details:"));
        inputPanel.add(detailsField);
        inputPanel.add(insertButton);
        inputPanel.add(refreshButton);

        add(inputPanel, BorderLayout.NORTH);

        insertButton.addActionListener(e -> insertAuctionResult());
        refreshButton.addActionListener(e -> loadAuctionResults());

        loadAuctionResults();
    }

    private void insertAuctionResult() {
        int id = Integer.parseInt(idField.getText());
        String details = detailsField.getText();
        Timestamp time = new Timestamp(System.currentTimeMillis());

        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"Auction_result\" (\"Result_id\", \"auction_time\", \"Details\") VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setTimestamp(2, time);
            ps.setString(3, details);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Inserted successfully!");
                loadAuctionResults();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void loadAuctionResults() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Auction_result\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("Result_id"),
                        rs.getTimestamp("auction_time"),
                        rs.getString("Details")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }
}