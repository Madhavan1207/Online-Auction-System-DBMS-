import java.sql.*;

public class Demo {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/Online_Auction";
        String user = "postgres";
        String password = "Madhavpostgre";

        try (Connection con = DriverManager.getConnection(url, user, password)) {
            System.out.println("✅ Connected to PostgreSQL database!");

            String insertSQL = "INSERT INTO \"Auction_result\" (\"Result_id\", \"auction_time\", \"Details\") VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(insertSQL)) {
                ps.setInt(1, 11);
                ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
                ps.setString(3, "Easy to Work");
                int rowsInserted = ps.executeUpdate();
                if (rowsInserted > 0) System.out.println("✅ Record inserted successfully!");
            }

            String selectSQL = "SELECT * FROM \"Auction_result\"";
            try (Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(selectSQL)) {
                System.out.println("\n📋 Auction Results:");
                while (rs.next()) {
                    int id = rs.getInt("Result_id");
                    Timestamp time = rs.getTimestamp("auction_time");
                    String details = rs.getString("Details");
                    System.out.println(id + " | " + time + " | " + details);
                }
            }

        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        }
    }
}
