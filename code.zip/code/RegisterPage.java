import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RegisterPage extends JFrame {
    private JTextField usernameField;
    private JTextField nameField;
    private JPasswordField passwordField;
    private JComboBox<String> genderCombo;
    private JTextField phoneField;

    public RegisterPage() {
        setTitle("Register");
        setSize(400, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(7, 2, 8, 12));
        panel.setBorder(BorderFactory.createEmptyBorder(18, 28, 18, 28));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("Gender:"));
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        panel.add(genderCombo);

        panel.add(new JLabel("Phone No:"));
        phoneField = new JTextField();
        panel.add(phoneField);

        JButton registerBtn = new JButton("Register");
        panel.add(new JLabel());
        panel.add(registerBtn);

        // Back button
        JButton backBtn = new JButton("Back");
        backBtn.setFocusPainted(false);
        backBtn.setBackground(new Color(220, 220, 220));
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panel.add(new JLabel());
        panel.add(backBtn);

        add(panel);

        registerBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String name = nameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String gender = (String)genderCombo.getSelectedItem();
            String phoneText = phoneField.getText().trim();

            if (username.isEmpty() || name.isEmpty() || password.isEmpty() || gender.isEmpty() || phoneText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.");
                return;
            }

            long phoneNo;
            try {
                phoneNo = Long.parseLong(phoneText);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Phone number must be numeric.");
                return;
            }

            try (Connection con = DBUtil.getConnection()) {
                String sql = "INSERT INTO \"Customer\" (\"Username\", \"Name\", \"Password\", \"Gender\", \"Phone_no\") VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, name);
                ps.setString(3, password);
                ps.setString(4, gender);
                ps.setLong(5, phoneNo);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Account created! Database panel will open now.");
                new InitialPage().setVisible(true);
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
            }
        });

        backBtn.addActionListener(e -> {
            new AuctionPlatformLanding().setVisible(true);
            dispose();
        });
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignore) {}
        SwingUtilities.invokeLater(() -> new RegisterPage().setVisible(true));
    }
}
