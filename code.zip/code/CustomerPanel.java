import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class CustomerPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField usernameField, nameField, passwordField, genderField, phoneField, titleField;
    private JTextField searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;
    public CustomerPanel() {
        setTitle("Customer Management");
        setSize(950, 500);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Table
        model = new DefaultTableModel(new String[]{"Username", "Name", "Password", "Gender", "Phone_no", "Title"},0);
        table = new JTable(model); table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200,200,255));
        add(new JScrollPane(table), BorderLayout.CENTER);
        // Panel
        JPanel panel = new JPanel(new FlowLayout());
        usernameField=new JTextField(8); nameField=new JTextField(10);
        passwordField=new JTextField(8); genderField=new JTextField(2);
        phoneField=new JTextField(10); titleField=new JTextField(10);
        searchField=new JTextField(10);
        insertBtn=new JButton("Insert"); updateBtn=new JButton("Update");
        deleteBtn=new JButton("Delete"); refreshBtn=new JButton("Refresh");
        exportBtn=new JButton("Export CSV"); searchBtn=new JButton("Search");
        // Tooltips
        usernameField.setToolTipText("Username (PK)");
        // add components
        panel.add(new JLabel("User:")); panel.add(usernameField);
        panel.add(new JLabel("Name:")); panel.add(nameField);
        panel.add(new JLabel("Pass:")); panel.add(passwordField);
        panel.add(new JLabel("Gen:")); panel.add(genderField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);
        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search:")); panel.add(searchField); panel.add(searchBtn); panel.add(exportBtn);
        add(panel, BorderLayout.NORTH);
        // actions
        insertBtn.addActionListener(e -> insertCustomer());
        updateBtn.addActionListener(e -> updateCustomer());
        deleteBtn.addActionListener(e -> deleteCustomer());
        refreshBtn.addActionListener(e -> loadCustomers());
        searchBtn.addActionListener(e -> searchCustomer(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        loadCustomers();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if(row>=0){
            usernameField.setText((String)model.getValueAt(row,0));
            nameField.setText((String)model.getValueAt(row,1));
            passwordField.setText((String)model.getValueAt(row,2));
            genderField.setText((String)model.getValueAt(row,3));
            phoneField.setText((String)model.getValueAt(row,4));
            titleField.setText((String)model.getValueAt(row,5));
        }
    }

    private void insertCustomer() {
        try (Connection con=DBUtil.getConnection()) {
            String sql="INSERT INTO \"Customer\" (\"Username\",\"Name\",\"Password\",\"Gender\",\"Phone_no\",\"Title\") VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,usernameField.getText()); ps.setString(2,nameField.getText());
            ps.setString(3,passwordField.getText()); ps.setString(4,genderField.getText());
            ps.setString(5,phoneField.getText()); ps.setString(6,titleField.getText());
            int r=ps.executeUpdate();
            JOptionPane.showMessageDialog(this, r>0?"Inserted!":"Failed");
            loadCustomers();
        }catch (SQLException ex){JOptionPane.showMessageDialog(this, ex);}
    }
    private void updateCustomer() {
        try (Connection con=DBUtil.getConnection()) {
            String sql="UPDATE \"Customer\" SET \"Name\"=?, \"Password\"=?, \"Gender\"=?, \"Phone_no\"=?, \"Title\"=? WHERE \"Username\"=?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,nameField.getText()); ps.setString(2,passwordField.getText());
            ps.setString(3,genderField.getText()); ps.setString(4,phoneField.getText()); ps.setString(5,titleField.getText());
            ps.setString(6,usernameField.getText());
            int r=ps.executeUpdate();
            JOptionPane.showMessageDialog(this, r>0?"Updated":"Failed");
            loadCustomers();
        } catch (SQLException ex){ JOptionPane.showMessageDialog(this, ex); }
    }
    private void deleteCustomer() {
        int r=JOptionPane.showConfirmDialog(this, "Delete customer?","Confirm",JOptionPane.YES_NO_OPTION);
        if(r==JOptionPane.YES_OPTION){
            try (Connection con=DBUtil.getConnection()){
                String sql="DELETE FROM \"Customer\" WHERE \"Username\"=?";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1,usernameField.getText());
                int rs=ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rs>0?"Deleted":"Failed");
                loadCustomers();
            }catch (SQLException ex){ JOptionPane.showMessageDialog(this, ex); }
        }
    }
    private void loadCustomers() {
        model.setRowCount(0);
        try (Connection con=DBUtil.getConnection()){
            String sql="SELECT * FROM \"Customer\"";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                model.addRow(new Object[]{rs.getString("Username"), rs.getString("Name"), rs.getString("Password"), rs.getString("Gender"), rs.getString("Phone_no"), rs.getString("Title")});
            }
        }catch (SQLException ex){ JOptionPane.showMessageDialog(this, "DB err:"+ex); }
    }
    private void searchCustomer(String name) {
        if(name.isEmpty()){ loadCustomers(); return; }
        model.setRowCount(0);
        try (Connection con=DBUtil.getConnection()){
            String sql="SELECT * FROM \"Customer\" WHERE \"Name\" ILIKE ?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1, "%"+name+"%");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{ rs.getString("Username"), rs.getString("Name"), rs.getString("Password"), rs.getString("Gender"), rs.getString("Phone_no"), rs.getString("Title")});
            }
        }catch (SQLException ex){ JOptionPane.showMessageDialog(this, "DB err:"+ex); }
    }
    private void exportTableToCSV() {
        JFileChooser chooser=new JFileChooser();
        if(chooser.showSaveDialog(this)==JFileChooser.APPROVE_OPTION){
            try (FileWriter fw=new FileWriter(chooser.getSelectedFile())){
                for(int i=0;i<model.getRowCount();i++){
                    for(int j=0;j<model.getColumnCount();j++){
                        fw.write(String.valueOf(model.getValueAt(i,j)));
                        if(j<model.getColumnCount()-1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported");
            } catch (Exception e){ JOptionPane.showMessageDialog(this, e); }
        }
    }
}