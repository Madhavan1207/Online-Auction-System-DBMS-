import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class CustomerPhonePanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField usernameField, phoneField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public CustomerPhonePanel() {
        setTitle("Customer Phone Numbers");
        setSize(800, 450);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"Username", "Phone_no"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        usernameField = new JTextField(10);
        phoneField = new JTextField(15);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Username:")); panel.add(usernameField);
        panel.add(new JLabel("Phone No:")); panel.add(phoneField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Username:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertPhone());
        updateBtn.addActionListener(e -> updatePhone());
        deleteBtn.addActionListener(e -> deletePhone());
        refreshBtn.addActionListener(e -> loadPhones());
        searchBtn.addActionListener(e -> searchPhonesByUsername(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadPhones();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            usernameField.setText((String) model.getValueAt(row, 0));
            phoneField.setText((String) model.getValueAt(row, 1));
        }
    }

    private void insertPhone() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"Customer_Phone_no\" (\"Username\", \"Phone_no\") VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usernameField.getText());
            ps.setString(2, phoneField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadPhones();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void updatePhone() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"Customer_Phone_no\" SET \"Phone_no\"=? WHERE \"Username\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, phoneField.getText());
            ps.setString(2, usernameField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadPhones();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void deletePhone() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected phone?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"Customer_Phone_no\" WHERE \"Username\"=? AND \"Phone_no\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, usernameField.getText());
                ps.setString(2, phoneField.getText());
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadPhones();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error: "+ex.getMessage());
            }
        }
    }

    private void loadPhones() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Customer_Phone_no\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getString("Username"),
                        rs.getString("Phone_no")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: "+ex.getMessage());
        }
    }

    private void searchPhonesByUsername(String username) {
        if (username.isEmpty()) {
            loadPhones();
            return;
        }
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Customer_Phone_no\" WHERE \"Username\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + username + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getString("Username"),
                        rs.getString("Phone_no")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: "+ex.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile())) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount() - 1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Export error: "+e.getMessage());
            }
        }
    }
}
