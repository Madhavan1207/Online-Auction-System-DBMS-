import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ReadOnly extends JFrame {

    public ReadOnly() {
        setTitle("Database Viewer (Read-Only)");
        setSize(800, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Create a non-editable table model
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Disable editing
            }
        };

        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        JScrollPane scrollPane = new JScrollPane(table);

        // Define columns
        model.addColumn("Username");
        model.addColumn("Name");
        model.addColumn("Password");
        model.addColumn("Gender");
        model.addColumn("Phone No");

        // Load data from database
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT \"Username\", \"Name\", \"Password\", \"Gender\", \"Phone_no\" FROM \"Customer\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("Username"),
                        rs.getString("Name"),
                        rs.getString("Password"),
                        rs.getString("Gender"),
                        rs.getLong("Phone_no")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage());
        }

        add(scrollPane, BorderLayout.CENTER);

        // Back Button
        JButton backBtn = new JButton("Back");
        backBtn.setFocusPainted(false);
        backBtn.setBackground(new Color(220, 220, 220));
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backBtn);

        add(bottomPanel, BorderLayout.SOUTH);

        backBtn.addActionListener(e -> {
            new AuctionPlatformLanding().setVisible(true);
            dispose();
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ReadOnly().setVisible(true));
    }
}


