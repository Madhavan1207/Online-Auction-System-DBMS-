import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class BidPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField bidIdField, bidAmountField, bidTimeField, statusField, usernameField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public BidPanel() {
        setTitle("Bid Management");
        setSize(900, 500);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"bid_id", "bid_amount", "bid_time", "Status", "Username"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        bidIdField = new JTextField(10);
        bidAmountField = new JTextField(10);
        bidTimeField = new JTextField(15);
        statusField = new JTextField(10);
        usernameField = new JTextField(10);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Bid ID:")); panel.add(bidIdField);
        panel.add(new JLabel("Bid Amount:")); panel.add(bidAmountField);
        panel.add(new JLabel("Bid Time (YYYY-MM-DD HH:MM:SS):")); panel.add(bidTimeField);
        panel.add(new JLabel("Status:")); panel.add(statusField);
        panel.add(new JLabel("Username:")); panel.add(usernameField);

        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Username:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertBid());
        updateBtn.addActionListener(e -> updateBid());
        deleteBtn.addActionListener(e -> deleteBid());
        refreshBtn.addActionListener(e -> loadBids());
        searchBtn.addActionListener(e -> searchBidByUsername(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadBids();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            bidIdField.setText(model.getValueAt(row, 0).toString());
            bidAmountField.setText(model.getValueAt(row, 1).toString());
            bidTimeField.setText(model.getValueAt(row, 2).toString());
            statusField.setText((String) model.getValueAt(row, 3));
            usernameField.setText((String) model.getValueAt(row, 4));
        }
    }

    private void insertBid() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"bid\" (\"bid_id\", \"bid_amount\", \"bid_time\", \"Status\", \"Username\") VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(bidIdField.getText()));
            ps.setBigDecimal(2, new java.math.BigDecimal(bidAmountField.getText()));
            ps.setTimestamp(3, Timestamp.valueOf(bidTimeField.getText()));
            ps.setString(4, statusField.getText());
            ps.setString(5, usernameField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadBids();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
        }
    }

    private void updateBid() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"bid\" SET \"bid_amount\"=?, \"bid_time\"=?, \"Status\"=?, \"Username\"=? WHERE \"bid_id\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setBigDecimal(1, new java.math.BigDecimal(bidAmountField.getText()));
            ps.setTimestamp(2, Timestamp.valueOf(bidTimeField.getText()));
            ps.setString(3, statusField.getText());
            ps.setString(4, usernameField.getText());
            ps.setInt(5, Integer.parseInt(bidIdField.getText()));
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadBids();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
        }
    }

    private void deleteBid() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected bid?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"bid\" WHERE \"bid_id\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(bidIdField.getText()));
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadBids();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
            }
        }
    }

    private void loadBids() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"bid\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("bid_id"),
                        rs.getBigDecimal("bid_amount"),
                        rs.getTimestamp("bid_time").toString(),
                        rs.getString("Status"),
                        rs.getString("Username")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
        }
    }

    private void searchBidByUsername(String username) {
        if (username.isEmpty()) {
            loadBids();
            return;
        }
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"bid\" WHERE \"Username\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + username + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("bid_id"),
                        rs.getBigDecimal("bid_amount"),
                        rs.getTimestamp("bid_time").toString(),
                        rs.getString("Status"),
                        rs.getString("Username")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile())) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount() - 1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Export error: " + e.getMessage());
            }
        }
    }
}

