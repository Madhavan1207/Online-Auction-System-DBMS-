import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class ItemsPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField titleField, startDateField, endDateField, startPriceField, resultIdField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public ItemsPanel() {
        setTitle("Items Management");
        setSize(1000, 500);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"Title", "Start Date", "End Date", "Start Price", "Result Id"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());
        titleField = new JTextField(10);
        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startPriceField = new JTextField(10);
        resultIdField = new JTextField(8);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(new JLabel("Start Date (YYYY-MM-DD):")); panel.add(startDateField);
        panel.add(new JLabel("End Date (YYYY-MM-DD):")); panel.add(endDateField);
        panel.add(new JLabel("Start Price:")); panel.add(startPriceField);
        panel.add(new JLabel("Result ID:")); panel.add(resultIdField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Title:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertItem());
        updateBtn.addActionListener(e -> updateItem());
        deleteBtn.addActionListener(e -> deleteItem());
        refreshBtn.addActionListener(e -> loadItems());
        searchBtn.addActionListener(e -> searchItemByTitle(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadItems();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if(row >= 0) {
            titleField.setText((String) model.getValueAt(row, 0));
            startDateField.setText((String) model.getValueAt(row, 1));
            endDateField.setText((String) model.getValueAt(row, 2));
            startPriceField.setText(model.getValueAt(row, 3).toString());
            resultIdField.setText(model.getValueAt(row, 4) != null ? model.getValueAt(row, 4).toString() : "");
        }
    }

    private void insertItem() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"items\" (\"Title\", \"start_date\", \"end_date\", \"start_price\", \"result_id\") VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, titleField.getText());
            ps.setDate(2, Date.valueOf(startDateField.getText()));
            ps.setDate(3, Date.valueOf(endDateField.getText()));
            ps.setBigDecimal(4, new java.math.BigDecimal(startPriceField.getText()));
            ps.setInt(5, Integer.parseInt(resultIdField.getText()));
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadItems();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void updateItem() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"items\" SET \"start_date\"=?, \"end_date\"=?, \"start_price\"=?, \"result_id\"=? WHERE \"Title\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(startDateField.getText()));
            ps.setDate(2, Date.valueOf(endDateField.getText()));
            ps.setBigDecimal(3, new java.math.BigDecimal(startPriceField.getText()));
            ps.setInt(4, Integer.parseInt(resultIdField.getText()));
            ps.setString(5, titleField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadItems();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void deleteItem() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected item?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"items\" WHERE \"Title\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, titleField.getText());
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadItems();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
            }
        }
    }

    private void loadItems() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"items\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("Title"),
                        rs.getDate("start_date").toString(),
                        rs.getDate("end_date").toString(),
                        rs.getBigDecimal("start_price"),
                        rs.getObject("result_id")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void searchItemByTitle(String title) {
        if (title.isEmpty()) {
            loadItems();
            return;
        }
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"items\" WHERE \"Title\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + title + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("Title"),
                        rs.getDate("start_date").toString(),
                        rs.getDate("end_date").toString(),
                        rs.getBigDecimal("start_price"),
                        rs.getObject("result_id")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile())) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount() - 1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Export error: "+ e.getMessage());
            }
        }
    }
}

