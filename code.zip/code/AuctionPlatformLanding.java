import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

public class AuctionPlatformLanding extends JFrame {
    public AuctionPlatformLanding() {
        setTitle("Auction Platform");
        setSize(500, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bg = new JPanel(new GridBagLayout());
        bg.setBackground(new Color(245, 245, 250));
        add(bg);

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(new LineBorder(new Color(220, 220, 220), 2, true));
        card.setPreferredSize(new Dimension(360, 470));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        bg.add(card, new GridBagConstraints());

        card.add(Box.createVerticalStrut(40));
        JLabel heading = new JLabel("<html><div style='text-align:center;'>Welcome to<br><b>AUCTION PLATFORM</b></div></html>", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 20));
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        heading.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(heading);

        card.add(Box.createVerticalStrut(18));

        JLabel logo = new JLabel();
        // Uncomment and replace with a logo image path if available
        // logo.setIcon(new ImageIcon("auction_logo.png"));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(logo);

        card.add(Box.createVerticalGlue());

        JButton registerBtn = new JButton("REGISTER");
        registerBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerBtn.setBackground(new Color(106, 121, 247));
        registerBtn.setForeground(Color.GREEN);
        registerBtn.setFocusPainted(false);
        registerBtn.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(registerBtn);

        card.add(Box.createVerticalStrut(14));

        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setBackground(Color.WHITE);
        loginBtn.setForeground(Color.BLACK);
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(new LineBorder(new Color(106, 121, 247), 2, true));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(loginBtn);

        // View Database button (text only, change to icon by setIcon if desired)
        JButton dbViewBtn = new JButton("VIEW DATABASE");
        dbViewBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        dbViewBtn.setBackground(new Color(225, 225, 240));
        dbViewBtn.setForeground(new Color(52, 53, 92));
        dbViewBtn.setFocusPainted(false);
        dbViewBtn.setBorder(BorderFactory.createLineBorder(new Color(106, 121, 247), 1, true));
        dbViewBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(Box.createVerticalStrut(12));
        card.add(dbViewBtn);

        card.add(Box.createVerticalGlue());

        JLabel terms = new JLabel("Read terms and privacy policy.");
        terms.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        terms.setForeground(new Color(130, 130, 130));
        terms.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(terms);

        card.add(Box.createVerticalStrut(18));

        // Button actions
        registerBtn.addActionListener(e -> openRegisterPage());
        loginBtn.addActionListener(e -> openLoginPage());
        dbViewBtn.addActionListener(e -> openDatabaseViewer());
    }

    private void openRegisterPage() {
        new RegisterPage().setVisible(true);
        setVisible(false);
    }

    private void openLoginPage() {
        new LoginPage().setVisible(true);
        setVisible(false);
    }

    private void openDatabaseViewer() {
        new ReadOnly().setVisible(true); // your read-only database viewer JFrame
        setVisible(false);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignore) {}
        SwingUtilities.invokeLater(() -> new AuctionPlatformLanding().setVisible(true));
    }
}


