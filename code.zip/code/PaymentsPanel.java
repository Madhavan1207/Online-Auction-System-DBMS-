import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class PaymentsPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField paymentIdField, paymentDateField, methodField, titleField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public PaymentsPanel() {
        setTitle("Payments Management");
        setSize(900, 450);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"Payment_id", "Payment_date", "Method", "Title"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        paymentIdField = new JTextField(10);
        paymentDateField = new JTextField(10);
        methodField = new JTextField(10);
        titleField = new JTextField(10);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Payment ID:")); panel.add(paymentIdField);
        panel.add(new JLabel("Payment Date (YYYY-MM-DD):")); panel.add(paymentDateField);
        panel.add(new JLabel("Method:")); panel.add(methodField);
        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Title:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        // Action listeners
        insertBtn.addActionListener(e -> insertPayment());
        updateBtn.addActionListener(e -> updatePayment());
        deleteBtn.addActionListener(e -> deletePayment());
        refreshBtn.addActionListener(e -> loadPayments());
        searchBtn.addActionListener(e -> searchPaymentByTitle(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadPayments();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            paymentIdField.setText(model.getValueAt(row, 0).toString());
            paymentDateField.setText((String) model.getValueAt(row, 1));
            methodField.setText((String) model.getValueAt(row, 2));
            titleField.setText((String) model.getValueAt(row, 3));
        }
    }

    private void insertPayment() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"Payments\" (\"Payment_id\", \"payment_date\", \"Method\", \"Title\") VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(paymentIdField.getText()));
            ps.setDate(2, Date.valueOf(paymentDateField.getText()));
            ps.setString(3, methodField.getText());
            ps.setString(4, titleField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadPayments();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void updatePayment() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"Payments\" SET \"payment_date\"=?, \"Method\"=?, \"Title\"=? WHERE \"Payment_id\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(paymentDateField.getText()));
            ps.setString(2, methodField.getText());
            ps.setString(3, titleField.getText());
            ps.setInt(4, Integer.parseInt(paymentIdField.getText()));
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadPayments();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void deletePayment() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected payment?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"Payments\" WHERE \"Payment_id\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(paymentIdField.getText()));
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadPayments();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
            }
        }
    }

    private void loadPayments() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Payments\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("Payment_id"),
                        rs.getDate("payment_date").toString(),
                        rs.getString("Method"),
                        rs.getString("Title")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void searchPaymentByTitle(String title) {
        if (title.isEmpty()) {
            loadPayments();
            return;
        }
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Payments\" WHERE \"Title\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + title + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("Payment_id"),
                        rs.getDate("payment_date").toString(),
                        rs.getString("Method"),
                        rs.getString("Title")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile())) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount() - 1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Export error: " + e.getMessage());
            }
        }
    }
}

