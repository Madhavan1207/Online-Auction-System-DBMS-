import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class WatchlistPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField watchlistIdField, addedDateField, statusField, titleField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public WatchlistPanel() {
        setTitle("Watchlist Management");
        setSize(900, 450);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"watchlist_id", "added_date", "status", "Title"},0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200,200,255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        watchlistIdField = new JTextField(10);
        addedDateField = new JTextField(10);
        statusField = new JTextField(10);
        titleField = new JTextField(10);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Watchlist ID:")); panel.add(watchlistIdField);
        panel.add(new JLabel("Added Date (YYYY-MM-DD):")); panel.add(addedDateField);
        panel.add(new JLabel("Status:")); panel.add(statusField);
        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Title:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertWatchlist());
        updateBtn.addActionListener(e -> updateWatchlist());
        deleteBtn.addActionListener(e -> deleteWatchlist());
        refreshBtn.addActionListener(e -> loadWatchlist());
        searchBtn.addActionListener(e -> searchWatchlist(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadWatchlist();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if(row >= 0) {
            watchlistIdField.setText(model.getValueAt(row, 0).toString());
            addedDateField.setText(model.getValueAt(row, 1).toString());
            statusField.setText((String) model.getValueAt(row, 2));
            titleField.setText((String) model.getValueAt(row, 3));
        }
    }

    private void insertWatchlist() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"Watchlist\" (\"watchlist_id\", \"added_date\", \"Status\", \"Title\") VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(watchlistIdField.getText()));
            ps.setDate(2, Date.valueOf(addedDateField.getText()));
            ps.setString(3, statusField.getText());
            ps.setString(4, titleField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadWatchlist();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void updateWatchlist() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"Watchlist\" SET \"added_date\"=?, \"Status\"=?, \"Title\"=? WHERE \"watchlist_id\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(addedDateField.getText()));
            ps.setString(2, statusField.getText());
            ps.setString(3, titleField.getText());
            ps.setInt(4, Integer.parseInt(watchlistIdField.getText()));
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadWatchlist();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void deleteWatchlist() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected watchlist record?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if(r == JOptionPane.YES_OPTION){
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"Watchlist\" WHERE \"watchlist_id\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(watchlistIdField.getText()));
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadWatchlist();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
            }
        }
    }

    private void loadWatchlist() {
        model.setRowCount(0);
        try(Connection con = DBUtil.getConnection()){
            String sql = "SELECT * FROM \"Watchlist\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                model.addRow(new Object[] {
                        rs.getInt("watchlist_id"),
                        rs.getDate("added_date").toString(),
                        rs.getString("Status"),
                        rs.getString("Title")
                });
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void searchWatchlist(String title) {
        if(title.isEmpty()) {
            loadWatchlist();
            return;
        }
        model.setRowCount(0);
        try(Connection con = DBUtil.getConnection()){
            String sql = "SELECT * FROM \"Watchlist\" WHERE \"Title\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + title + "%");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("watchlist_id"),
                        rs.getDate("added_date").toString(),
                        rs.getString("Status"),
                        rs.getString("Title")
                });
            }
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if(chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION){
            try(FileWriter fw = new FileWriter(chooser.getSelectedFile())){
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i, j) != null ? model.getValueAt(i, j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount() - 1) {
                            fw.write(",");
                        }
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e){
                JOptionPane.showMessageDialog(this, "Export error: " + e.getMessage());
            }
        }
    }
}

