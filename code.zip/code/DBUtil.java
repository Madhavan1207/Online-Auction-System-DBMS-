import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:postgresql://localhost:5432/Online_Auction";
        String user = "postgres";
        String password = "Madhavpostgre";

        return DriverManager.getConnection(url, user, password);
    }
}
