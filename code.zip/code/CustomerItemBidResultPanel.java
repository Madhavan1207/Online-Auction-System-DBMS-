import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class CustomerItemBidResultPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField usernameField, titleField, bidIdField, resultIdField, bidAmountField, passwordField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public CustomerItemBidResultPanel() {
        setTitle("Customer-Item-Bid-Result Management");
        setSize(1100, 500);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"Username", "Title", "bid_id", "result_id", "bid_amount", "Password"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        usernameField = new JTextField(10);
        titleField = new JTextField(15);
        bidIdField = new JTextField(8);
        resultIdField = new JTextField(8);
        bidAmountField = new JTextField(10);
        passwordField = new JTextField(10);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Username:")); panel.add(usernameField);
        panel.add(new JLabel("Title:")); panel.add(titleField);
        panel.add(new JLabel("Bid ID:")); panel.add(bidIdField);
        panel.add(new JLabel("Result ID:")); panel.add(resultIdField);
        panel.add(new JLabel("Bid Amount:")); panel.add(bidAmountField);
        panel.add(new JLabel("Password:")); panel.add(passwordField);

        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Username:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertRecord());
        updateBtn.addActionListener(e -> updateRecord());
        deleteBtn.addActionListener(e -> deleteRecord());
        refreshBtn.addActionListener(e -> loadRecords());
        searchBtn.addActionListener(e -> searchByUsername(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadRecords();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if(row >= 0){
            usernameField.setText((String) model.getValueAt(row,0));
            titleField.setText((String) model.getValueAt(row,1));
            bidIdField.setText(model.getValueAt(row,2).toString());
            resultIdField.setText(model.getValueAt(row,3).toString());
            bidAmountField.setText(model.getValueAt(row,4).toString());
            passwordField.setText((String) model.getValueAt(row,5));
        }
    }

    private void insertRecord() {
        try(Connection con=DBUtil.getConnection()){
            String sql="INSERT INTO \"Customer_item_bid_Result\" (\"Username\", \"Title\", \"bid_id\", \"result_id\", \"bid_amount\", \"Password\") VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,usernameField.getText());
            ps.setString(2,titleField.getText());
            ps.setInt(3,Integer.parseInt(bidIdField.getText()));
            ps.setInt(4,Integer.parseInt(resultIdField.getText()));
            ps.setBigDecimal(5, new java.math.BigDecimal(bidAmountField.getText()));
            ps.setString(6,passwordField.getText());
            int rows=ps.executeUpdate();
            JOptionPane.showMessageDialog(this,rows>0?"Inserted!":"Insert failed");
            loadRecords();
        }catch(SQLException ex){JOptionPane.showMessageDialog(this,"DB Error :"+ex.getMessage());}
    }

    private void updateRecord() {
        try(Connection con=DBUtil.getConnection()){
            String sql="UPDATE \"Customer_item_bid_Result\" SET \"Title\"=?, \"result_id\"=?, \"bid_amount\"=?, \"Password\"=? WHERE \"Username\"=? AND \"bid_id\"=?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1,titleField.getText());
            ps.setInt(2,Integer.parseInt(resultIdField.getText()));
            ps.setBigDecimal(3, new java.math.BigDecimal(bidAmountField.getText()));
            ps.setString(4,passwordField.getText());
            ps.setString(5,usernameField.getText());
            ps.setInt(6,Integer.parseInt(bidIdField.getText()));
            int rows=ps.executeUpdate();
            JOptionPane.showMessageDialog(this,rows>0?"Updated!":"Update failed");
            loadRecords();
        }catch(SQLException ex){JOptionPane.showMessageDialog(this,"DB Error :"+ex.getMessage());}
    }

    private void deleteRecord() {
        int r=JOptionPane.showConfirmDialog(this,"Delete selected record?","Confirm Delete",JOptionPane.YES_NO_OPTION);
        if(r==JOptionPane.YES_OPTION){
            try(Connection con=DBUtil.getConnection()){
                String sql="DELETE FROM \"Customer_item_bid_Result\" WHERE \"Username\"=? AND \"bid_id\"=?";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1,usernameField.getText());
                ps.setInt(2,Integer.parseInt(bidIdField.getText()));
                int rows=ps.executeUpdate();
                JOptionPane.showMessageDialog(this,rows>0?"Deleted!":"Delete failed");
                loadRecords();
            }catch(SQLException ex){JOptionPane.showMessageDialog(this,"DB Error :"+ex.getMessage());}
        }
    }

    private void loadRecords() {
        model.setRowCount(0);
        try(Connection con=DBUtil.getConnection()){
            String sql="SELECT * FROM \"Customer_item_bid_Result\"";
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("Username"),
                        rs.getString("Title"),
                        rs.getInt("bid_id"),
                        rs.getInt("result_id"),
                        rs.getBigDecimal("bid_amount"),
                        rs.getString("Password")
                });
            }
        }catch(SQLException ex){JOptionPane.showMessageDialog(this,"DB Error :"+ex.getMessage());}
    }

    private void searchByUsername(String username) {
        if(username.isEmpty()){loadRecords();return;}
        model.setRowCount(0);
        try(Connection con=DBUtil.getConnection()){
            String sql="SELECT * FROM \"Customer_item_bid_Result\" WHERE \"Username\" ILIKE ?";
            PreparedStatement ps=con.prepareStatement(sql);
            ps.setString(1, "%"+username+"%");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("Username"),
                        rs.getString("Title"),
                        rs.getInt("bid_id"),
                        rs.getInt("result_id"),
                        rs.getBigDecimal("bid_amount"),
                        rs.getString("Password")
                });
            }
        }catch(SQLException ex){JOptionPane.showMessageDialog(this,"DB Error :"+ex.getMessage());}
    }

    private void exportTableToCSV() {
        JFileChooser chooser=new JFileChooser();
        if(chooser.showSaveDialog(this)==JFileChooser.APPROVE_OPTION){
            try(FileWriter fw=new FileWriter(chooser.getSelectedFile())){
                for(int i=0;i<model.getRowCount();i++){
                    for(int j=0;j<model.getColumnCount();j++){
                        String data=model.getValueAt(i,j)!=null?model.getValueAt(i,j).toString():"";
                        fw.write(data);
                        if(j<model.getColumnCount()-1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this,"Exported!");
            }catch(Exception e){JOptionPane.showMessageDialog(this,"Export error: "+e.getMessage());}
        }
    }
}
