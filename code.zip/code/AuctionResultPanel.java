import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.io.FileWriter;

public class AuctionResultPanel extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField resultIdField, auctionTimeField, detailsField, searchField;
    private JButton insertBtn, updateBtn, deleteBtn, refreshBtn, searchBtn, exportBtn;

    public AuctionResultPanel() {
        setTitle("Auction Result Management");
        setSize(900, 450);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored){}
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        model = new DefaultTableModel(new String[]{"Result_id", "Auction_time", "Details"}, 0);
        table = new JTable(model);
        table.setAutoCreateRowSorter(true);
        table.setSelectionBackground(new Color(200, 200, 255));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel panel = new JPanel(new FlowLayout());

        resultIdField = new JTextField(10);
        auctionTimeField = new JTextField(15);
        detailsField = new JTextField(20);
        searchField = new JTextField(10);

        insertBtn = new JButton("Insert");
        updateBtn = new JButton("Update");
        deleteBtn = new JButton("Delete");
        refreshBtn = new JButton("Refresh");
        searchBtn = new JButton("Search");
        exportBtn = new JButton("Export CSV");

        panel.add(new JLabel("Result ID:")); panel.add(resultIdField);
        panel.add(new JLabel("Auction Time (YYYY-MM-DD HH:MM):")); panel.add(auctionTimeField);
        panel.add(new JLabel("Details:")); panel.add(detailsField);
        panel.add(insertBtn); panel.add(updateBtn); panel.add(deleteBtn);
        panel.add(refreshBtn); panel.add(new JLabel("Search Details:")); panel.add(searchField);
        panel.add(searchBtn); panel.add(exportBtn);

        add(panel, BorderLayout.NORTH);

        insertBtn.addActionListener(e -> insertAuctionResult());
        updateBtn.addActionListener(e -> updateAuctionResult());
        deleteBtn.addActionListener(e -> deleteAuctionResult());
        refreshBtn.addActionListener(e -> loadAuctionResults());
        searchBtn.addActionListener(e -> searchAuctionResultByDetails(searchField.getText()));
        exportBtn.addActionListener(e -> exportTableToCSV());
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());

        loadAuctionResults();
        setLocationRelativeTo(null);
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if(row >= 0) {
            resultIdField.setText(model.getValueAt(row, 0).toString());
            auctionTimeField.setText(model.getValueAt(row, 1).toString());
            detailsField.setText((String) model.getValueAt(row, 2));
        }
    }

    private void insertAuctionResult() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO \"Auction_result\" (\"Result_id\", \"auction_time\", \"Details\") VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(resultIdField.getText()));
            ps.setTimestamp(2, Timestamp.valueOf(auctionTimeField.getText()+":00"));
            ps.setString(3, detailsField.getText());
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Inserted!" : "Insert failed.");
            loadAuctionResults();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void updateAuctionResult() {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE \"Auction_result\" SET \"auction_time\"=?, \"Details\"=? WHERE \"Result_id\"=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setTimestamp(1, Timestamp.valueOf(auctionTimeField.getText()+":00"));
            ps.setString(2, detailsField.getText());
            ps.setInt(3, Integer.parseInt(resultIdField.getText()));
            int rows = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "Updated!" : "Update failed.");
            loadAuctionResults();
        }catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
        }
    }

    private void deleteAuctionResult() {
        int r = JOptionPane.showConfirmDialog(this, "Delete selected auction result?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            try (Connection con = DBUtil.getConnection()) {
                String sql = "DELETE FROM \"Auction_result\" WHERE \"Result_id\"=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(resultIdField.getText()));
                int rows = ps.executeUpdate();
                JOptionPane.showMessageDialog(this, rows > 0 ? "Deleted!" : "Delete failed.");
                loadAuctionResults();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error: " + ex.getMessage());
            }
        }
    }

    private void loadAuctionResults() {
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Auction_result\"";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("Result_id"),
                        rs.getTimestamp("auction_time").toString(),
                        rs.getString("Details")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage());
        }
    }

    private void searchAuctionResultByDetails(String details) {
        if (details.isEmpty()) {
            loadAuctionResults();
            return;
        }
        model.setRowCount(0);
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM \"Auction_result\" WHERE \"Details\" ILIKE ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + details + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("Result_id"),
                        rs.getTimestamp("auction_time").toString(),
                        rs.getString("Details")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage());
        }
    }

    private void exportTableToCSV() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter fw = new FileWriter(chooser.getSelectedFile())) {
                for (int i=0; i < model.getRowCount(); i++) {
                    for (int j=0; j < model.getColumnCount(); j++) {
                        String data = model.getValueAt(i,j) != null ? model.getValueAt(i,j).toString() : "";
                        fw.write(data);
                        if (j < model.getColumnCount()-1) fw.write(",");
                    }
                    fw.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Exported!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Export error: "+e.getMessage());
            }
        }
    }
}
